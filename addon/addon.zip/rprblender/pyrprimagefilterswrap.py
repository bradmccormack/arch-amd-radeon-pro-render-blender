

VERSION_MAJOR = 1
VERSION_MINOR = 3
VERSION_REVISION = 0
COMMIT_INFO = 0xbbe1d75
SUCCESS = 0
ERROR_COMPUTE_API_NOT_SUPPORTED = -1
ERROR_OUT_OF_SYSTEM_MEMORY = -2
ERROR_OUT_OF_VIDEO_MEMORY = -3
ERROR_INVALID_IMAGE = -6
ERROR_UNSUPPORTED_IMAGE_FORMAT = -8
ERROR_INVALID_GL_TEXTURE = -9
ERROR_INVALID_CL_IMAGE = -10
ERROR_INVALID_OBJECT = -11
ERROR_INVALID_PARAMETER = -12
ERROR_INVALID_TAG = -13
ERROR_INVALID_CONTEXT = -15
ERROR_INVALID_QUEUE = -16
ERROR_INVALID_FILTER = -17
ERROR_INVALID_FILTER_ARGUMENT_NAME = -18
ERROR_UNIMPLEMENTED = -19
ERROR_INVALID_API_VERSION = -20
ERROR_INTERNAL_ERROR = -21
ERROR_IO_ERROR = -22
ERROR_INVALID_PARAMETER_TYPE = -23
ERROR_UNSUPPORTED = -24
PARAMETER_TYPE_FLOAT = 0x1
PARAMETER_TYPE_FLOAT2 = 0x2
PARAMETER_TYPE_FLOAT3 = 0x3
PARAMETER_TYPE_FLOAT4 = 0x4
PARAMETER_TYPE_IMAGE = 0x5
PARAMETER_TYPE_STRING = 0x6
PARAMETER_TYPE_UINT = 0x8
PARAMETER_TYPE_UINT2 = 0x9
PARAMETER_TYPE_FLOAT_ARRAY = 0xA
PARAMETER_TYPE_UINT_ARRAY = 0xB
PARAMETER_TYPE_IMAGE_ARRAY = 0xC
PARAMETER_TYPE_FLOAT16 = 0xD
PARAMETER_TYPE_UINT4 = 0xE
PARAMETER_TYPE_LOCAL_MEMORY = 0xF
PARAMETER_TYPE_INT2 = 0x10
COMPUTE_TYPE_FLOAT = 0x0
COMPUTE_TYPE_FLOAT16 = 0x1
BACKEND_API_OPENCL = 0
BACKEND_API_METAL = 1
BACKEND_API_DIRECTX12 = 2
IMAGE_DESC = 0x301
IMAGE_DATA_SIZEBYTE = 0x302
COMPONENT_TYPE_UINT8 = 0x1
COMPONENT_TYPE_FLOAT16 = 0x2
COMPONENT_TYPE_FLOAT32 = 0x3
IMAGE_MAP_READ = 0x1
IMAGE_MAP_WRITE = 0x2
IMAGE_FILTER_NORMALIZATION = 0x1
IMAGE_FILTER_GAMMA_CORRECTION = 0x2
IMAGE_FILTER_RESAMPLE = 0x3
IMAGE_FILTER_RESAMPLE_DYNAMIC = 0x24
IMAGE_FILTER_REMAP_RANGE = 0x28
IMAGE_FILTER_GAUSSIAN_BLUR = 0x4
IMAGE_FILTER_MOTION_BLUR = 0x1F
IMAGE_FILTER_COLOR_SPACE = 0x5
IMAGE_FILTER_HUE_SATURATION = 0x6
IMAGE_FILTER_FILMIC_TONEMAP = 0x7
IMAGE_FILTER_REINHARD02_TONEMAP = 0x8
IMAGE_FILTER_EXPONENTIAL_TONEMAP = 0x9
IMAGE_FILTER_LINEAR_TONEMAP = 0xA
IMAGE_FILTER_DRAGO_TONEMAP = 0xB
IMAGE_FILTER_BILATERAL_DENOISE = 0xC
IMAGE_FILTER_LWR_DENOISE = 0xD
IMAGE_FILTER_EAW_DENOISE = 0xE
IMAGE_FILTER_MEDIAN_DENOISE = 0x1E
IMAGE_FILTER_AI_DENOISE = 0x3E
IMAGE_FILTER_AI_UPSCALE = 0x3F
IMAGE_FILTER_OPENIMAGE_DENOISE = 0x4E
IMAGE_FILTER_MLAA = 0xF
IMAGE_FILTER_SOBEL = 0x10
IMAGE_FILTER_LAPLACE = 0x11
IMAGE_FILTER_EMBOSS = 0x20
IMAGE_FILTER_WEIGHTED_SUM = 0x12
IMAGE_FILTER_MULT = 0x13
IMAGE_FILTER_SCALAR_MULT = 0x31
IMAGE_FILTER_SHARPEN = 0x14
IMAGE_FILTER_MOTION_BUFFER = 0x15
IMAGE_FILTER_TEMPORAL_ACCUMULATOR = 0x16
IMAGE_FILTER_SHADOW_CATCHER = 0x17
IMAGE_FILTER_USER_DEFINED = 0x18
IMAGE_FILTER_DILATE_ERODE = 0x1A
IMAGE_FILTER_POSTERIZE = 0x1B
IMAGE_FILTER_BLOOM = 0x30
IMAGE_FILTER_SPREAD = 0x1C
IMAGE_FILTER_RGB_NOISE = 0x1D
IMAGE_FILTER_FLIP_VERT = 0x21
IMAGE_FILTER_FLIP_HOR = 0x22
IMAGE_FILTER_ROTATE = 0x23
IMAGE_FILTER_AUTOLINEAR_TONEMAP = 0x25
IMAGE_FILTER_MAXWHITE_TONEMAP = 0x26
IMAGE_FILTER_PHOTO_LINEAR_TONEMAP = 0x27
IMAGE_FILTER_PHOTO_TONEMAP = 0x29
IMAGE_INTERPOLATION_NEAREST = 0x0
IMAGE_INTERPOLATION_BILINEAR = 0x1
IMAGE_INTERPOLATION_BICUBIC = 0x2
IMAGE_INTERPOLATION_LANCZOS = 0x3
IMAGE_INTERPOLATION_LANCZOS4 = 0x4
IMAGE_INTERPOLATION_LANCZOS6 = 0x5
IMAGE_INTERPOLATION_LANCZOS12 = 0x6
IMAGE_INTERPOLATION_LANCZOS3 = 0x7
IMAGE_INTERPOLATION_KAISER = 0x8
IMAGE_INTERPOLATION_BLACKMAN = 0x9
IMAGE_INTERPOLATION_GAUSS = 0xA
IMAGE_INTERPOLATION_BOX = 0xB
IMAGE_INTERPOLATION_TENT = 0xC
IMAGE_INTERPOLATION_BELL = 0xD
IMAGE_INTERPOLATION_BSPLINE = 0xE
IMAGE_INTERPOLATION_QUADRATIC_INTERP = 0xF
IMAGE_INTERPOLATION_QUADRATIC_APPROX = 0x10
IMAGE_INTERPOLATION_QUADRATIC_MIX = 0x11
IMAGE_INTERPOLATION_MITCHELL = 0x12
IMAGE_INTERPOLATION_CATMULL = 0x13
IMAGE_FILTER_TYPE = 0x0
IMAGE_FILTER_PARAMETER_COUNT = 0x1
IMAGE_FILTER_DESCRIPTION = 0x2
PARAMETER_NAME_STRING = 0x1202
PARAMETER_TYPE = 0x1203
PARAMETER_DESCRIPTION = 0x1204
PARAMETER_VALUE = 0x1205
COLOR_SPACE_SRGB = 0x1
COLOR_SPACE_ADOBE_RGB = 0x2
COLOR_SPACE_REC2020 = 0x3
COLOR_SPACE_DCIP3 = 0x4
FALSE = 0
TRUE = 1
CONTEXT_KERNELS_SOURCE_DIR = 0x1
CONTEXT_KERNELS_CACHE_DIR = 0x2
AI_UPSCALE_MODE_GOOD_2X = 0x1
AI_UPSCALE_MODE_BEST_2X = 0x2
AI_UPSCALE_MODE_FAST_2X = 0x3
_constants_names = ['VERSION_MAJOR', 'VERSION_MINOR', 'VERSION_REVISION', 'COMMIT_INFO', 'SUCCESS', 'ERROR_COMPUTE_API_NOT_SUPPORTED', 'ERROR_OUT_OF_SYSTEM_MEMORY', 'ERROR_OUT_OF_VIDEO_MEMORY', 'ERROR_INVALID_IMAGE', 'ERROR_UNSUPPORTED_IMAGE_FORMAT', 'ERROR_INVALID_GL_TEXTURE', 'ERROR_INVALID_CL_IMAGE', 'ERROR_INVALID_OBJECT', 'ERROR_INVALID_PARAMETER', 'ERROR_INVALID_TAG', 'ERROR_INVALID_CONTEXT', 'ERROR_INVALID_QUEUE', 'ERROR_INVALID_FILTER', 'ERROR_INVALID_FILTER_ARGUMENT_NAME', 'ERROR_UNIMPLEMENTED', 'ERROR_INVALID_API_VERSION', 'ERROR_INTERNAL_ERROR', 'ERROR_IO_ERROR', 'ERROR_INVALID_PARAMETER_TYPE', 'ERROR_UNSUPPORTED', 'PARAMETER_TYPE_FLOAT', 'PARAMETER_TYPE_FLOAT2', 'PARAMETER_TYPE_FLOAT3', 'PARAMETER_TYPE_FLOAT4', 'PARAMETER_TYPE_IMAGE', 'PARAMETER_TYPE_STRING', 'PARAMETER_TYPE_UINT', 'PARAMETER_TYPE_UINT2', 'PARAMETER_TYPE_FLOAT_ARRAY', 'PARAMETER_TYPE_UINT_ARRAY', 'PARAMETER_TYPE_IMAGE_ARRAY', 'PARAMETER_TYPE_FLOAT16', 'PARAMETER_TYPE_UINT4', 'PARAMETER_TYPE_LOCAL_MEMORY', 'PARAMETER_TYPE_INT2', 'COMPUTE_TYPE_FLOAT', 'COMPUTE_TYPE_FLOAT16', 'BACKEND_API_OPENCL', 'BACKEND_API_METAL', 'BACKEND_API_DIRECTX12', 'IMAGE_DESC', 'IMAGE_DATA_SIZEBYTE', 'COMPONENT_TYPE_UINT8', 'COMPONENT_TYPE_FLOAT16', 'COMPONENT_TYPE_FLOAT32', 'IMAGE_MAP_READ', 'IMAGE_MAP_WRITE', 'IMAGE_FILTER_NORMALIZATION', 'IMAGE_FILTER_GAMMA_CORRECTION', 'IMAGE_FILTER_RESAMPLE', 'IMAGE_FILTER_RESAMPLE_DYNAMIC', 'IMAGE_FILTER_REMAP_RANGE', 'IMAGE_FILTER_GAUSSIAN_BLUR', 'IMAGE_FILTER_MOTION_BLUR', 'IMAGE_FILTER_COLOR_SPACE', 'IMAGE_FILTER_HUE_SATURATION', 'IMAGE_FILTER_FILMIC_TONEMAP', 'IMAGE_FILTER_REINHARD02_TONEMAP', 'IMAGE_FILTER_EXPONENTIAL_TONEMAP', 'IMAGE_FILTER_LINEAR_TONEMAP', 'IMAGE_FILTER_DRAGO_TONEMAP', 'IMAGE_FILTER_BILATERAL_DENOISE', 'IMAGE_FILTER_LWR_DENOISE', 'IMAGE_FILTER_EAW_DENOISE', 'IMAGE_FILTER_MEDIAN_DENOISE', 'IMAGE_FILTER_AI_DENOISE', 'IMAGE_FILTER_AI_UPSCALE', 'IMAGE_FILTER_OPENIMAGE_DENOISE', 'IMAGE_FILTER_MLAA', 'IMAGE_FILTER_SOBEL', 'IMAGE_FILTER_LAPLACE', 'IMAGE_FILTER_EMBOSS', 'IMAGE_FILTER_WEIGHTED_SUM', 'IMAGE_FILTER_MULT', 'IMAGE_FILTER_SCALAR_MULT', 'IMAGE_FILTER_SHARPEN', 'IMAGE_FILTER_MOTION_BUFFER', 'IMAGE_FILTER_TEMPORAL_ACCUMULATOR', 'IMAGE_FILTER_SHADOW_CATCHER', 'IMAGE_FILTER_USER_DEFINED', 'IMAGE_FILTER_DILATE_ERODE', 'IMAGE_FILTER_POSTERIZE', 'IMAGE_FILTER_BLOOM', 'IMAGE_FILTER_SPREAD', 'IMAGE_FILTER_RGB_NOISE', 'IMAGE_FILTER_FLIP_VERT', 'IMAGE_FILTER_FLIP_HOR', 'IMAGE_FILTER_ROTATE', 'IMAGE_FILTER_AUTOLINEAR_TONEMAP', 'IMAGE_FILTER_MAXWHITE_TONEMAP', 'IMAGE_FILTER_PHOTO_LINEAR_TONEMAP', 'IMAGE_FILTER_PHOTO_TONEMAP', 'IMAGE_INTERPOLATION_NEAREST', 'IMAGE_INTERPOLATION_BILINEAR', 'IMAGE_INTERPOLATION_BICUBIC', 'IMAGE_INTERPOLATION_LANCZOS', 'IMAGE_INTERPOLATION_LANCZOS4', 'IMAGE_INTERPOLATION_LANCZOS6', 'IMAGE_INTERPOLATION_LANCZOS12', 'IMAGE_INTERPOLATION_LANCZOS3', 'IMAGE_INTERPOLATION_KAISER', 'IMAGE_INTERPOLATION_BLACKMAN', 'IMAGE_INTERPOLATION_GAUSS', 'IMAGE_INTERPOLATION_BOX', 'IMAGE_INTERPOLATION_TENT', 'IMAGE_INTERPOLATION_BELL', 'IMAGE_INTERPOLATION_BSPLINE', 'IMAGE_INTERPOLATION_QUADRATIC_INTERP', 'IMAGE_INTERPOLATION_QUADRATIC_APPROX', 'IMAGE_INTERPOLATION_QUADRATIC_MIX', 'IMAGE_INTERPOLATION_MITCHELL', 'IMAGE_INTERPOLATION_CATMULL', 'IMAGE_FILTER_TYPE', 'IMAGE_FILTER_PARAMETER_COUNT', 'IMAGE_FILTER_DESCRIPTION', 'PARAMETER_NAME_STRING', 'PARAMETER_TYPE', 'PARAMETER_DESCRIPTION', 'PARAMETER_VALUE', 'COLOR_SPACE_SRGB', 'COLOR_SPACE_ADOBE_RGB', 'COLOR_SPACE_REC2020', 'COLOR_SPACE_DCIP3', 'FALSE', 'TRUE', 'CONTEXT_KERNELS_SOURCE_DIR', 'CONTEXT_KERNELS_CACHE_DIR', 'AI_UPSCALE_MODE_GOOD_2X', 'AI_UPSCALE_MODE_BEST_2X', 'AI_UPSCALE_MODE_FAST_2X']
_types_names = ['bool', 'bool', 'char', 'char', 'double', 'double', 'float', 'float', 'int', 'int', 'long', 'long', 'longlong', 'longlong', 'short', 'short', 'uchar', 'uchar', 'uint', 'uint', 'ulong', 'ulong', 'ushort', 'ushort', '_render_statistics', '_render_statistics', 'backend_api_type', 'backend_api_type', 'bitfield', 'bitfield', 'color_space', 'color_space', 'command_queue_t', 'command_queue_t', 'component_type', 'component_type', 'compute_type', 'compute_type', 'context_info', 'context_info', 'context_t', 'context_t', 'environment_override', 'environment_override', 'image_filter_info', 'image_filter_info', 'image_filter_t', 'image_filter_t', 'image_filter_type', 'image_filter_type', 'image_info', 'image_info', 'image_map_type', 'image_map_type', 'image_t', 'image_t', 'image_type', 'image_type', 'int64', 'int64', 'interpolation_operator', 'interpolation_operator', 'parameter_info', 'parameter_info', 'parameter_type', 'parameter_type', 'uint64', 'uint64', '_image_desc', '_image_desc', 'creation_flags', 'creation_flags', 'exec_command_queue_callback', 'exec_command_queue_callback', 'render_statistics', 'render_statistics', 'command_queue', 'command_queue', 'context', 'context', 'image', 'image', 'image_desc', 'image_desc', 'image_filter', 'image_filter']
def CommandQueueAttachImageFilter(command_queue, image_filter, input_image, output_image):
    return lib.rifCommandQueueAttachImageFilter(command_queue._get_handle() if command_queue else ffi.NULL, image_filter._get_handle() if image_filter else ffi.NULL, input_image._get_handle() if input_image else ffi.NULL, output_image._get_handle() if output_image else ffi.NULL)

def CommandQueueAttachImageFilterRect(command_queue, image_filter, input_image, output_image, x, y, w, h):
    return lib.rifCommandQueueAttachImageFilterRect(command_queue._get_handle() if command_queue else ffi.NULL, image_filter._get_handle() if image_filter else ffi.NULL, input_image._get_handle() if input_image else ffi.NULL, output_image._get_handle() if output_image else ffi.NULL, x, y, w, h)

def CommandQueueDetachImageFilter(command_queue, image_filter):
    return lib.rifCommandQueueDetachImageFilter(command_queue._get_handle() if command_queue else ffi.NULL, image_filter._get_handle() if image_filter else ffi.NULL)

def ContextCreateCommandQueue(context, command_queue):
    return lib.rifContextCreateCommandQueue(context._get_handle() if context else ffi.NULL, command_queue._handle_ptr if command_queue else ffi.NULL)

def ContextCreateImage(context, image_desc, data, out_image):
    return lib.rifContextCreateImage(context._get_handle() if context else ffi.NULL, image_desc, data, out_image._handle_ptr if out_image else ffi.NULL)

def ContextCreateImageFilter(context, type, out_effect):
    return lib.rifContextCreateImageFilter(context._get_handle() if context else ffi.NULL, type, out_effect._handle_ptr if out_effect else ffi.NULL)

def ContextCreateImageFromOpenClMemory(context, image_desc, mem, isImage, out_image):
    return lib.rifContextCreateImageFromOpenClMemory(context._get_handle() if context else ffi.NULL, image_desc, mem, isImage, out_image._handle_ptr if out_image else ffi.NULL)

def ContextCreateImageFromOpenGlTexture(context, target, miplevel, texture, out_image):
    return lib.rifContextCreateImageFromOpenGlTexture(context._get_handle() if context else ffi.NULL, target, miplevel, texture, out_image._handle_ptr if out_image else ffi.NULL)

def ContextExecuteCommandQueue(context, command_queue, executionFinishedCallbackFunction, data, time):
    return lib.rifContextExecuteCommandQueue(context._get_handle() if context else ffi.NULL, command_queue._get_handle() if command_queue else ffi.NULL, executionFinishedCallbackFunction, data, time)

def ContextGetDeviceInfo(context, name, vendor):
    return lib.rifContextGetDeviceInfo(context._get_handle() if context else ffi.NULL, name, vendor)

def ContextGetInfo(context, context_info, size, data, size_ret):
    return lib.rifContextGetInfo(context._get_handle() if context else ffi.NULL, context_info, size, data, size_ret)

def ContextSetInfo(context, context_info, data):
    return lib.rifContextSetInfo(context._get_handle() if context else ffi.NULL, context_info, data)

def CreateContext(api_version, backend_api_type, device_id, cache_path, out_context):
    return lib.rifCreateContext(api_version, backend_api_type, device_id, cache_path, out_context._handle_ptr if out_context else ffi.NULL)

def CreateContextFromOpenClContext(api_version, context, device, queue, cache_path, out_context):
    return lib.rifCreateContextFromOpenClContext(api_version, context, device, queue, cache_path, out_context._handle_ptr if out_context else ffi.NULL)

def CreateContextSharedWithOpenGl(api_version, device_id, cache_path, out_context):
    return lib.rifCreateContextSharedWithOpenGl(api_version, device_id, cache_path, out_context._handle_ptr if out_context else ffi.NULL)

def FlushQueue(command_queue):
    return lib.rifFlushQueue(command_queue._get_handle() if command_queue else ffi.NULL)

def GetDeviceCount(backend_api_type, deviceCount):
    return lib.rifGetDeviceCount(backend_api_type, deviceCount)

def GetErrorCodeDescription(error):
    return lib.rifGetErrorCodeDescription(error)

def GetErrorCodeString(error):
    return lib.rifGetErrorCodeString(error)

def GetKernelsDir(context, kernels_dir, size_ret):
    return lib.rifGetKernelsDir(context._get_handle() if context else ffi.NULL, kernels_dir, size_ret)

def ImageFilterClearParameterImage(image_filter, name):
    return lib.rifImageFilterClearParameterImage(image_filter._get_handle() if image_filter else ffi.NULL, name)

def ImageFilterGetInfo(image_filter, filter_info, size, data, size_ret):
    return lib.rifImageFilterGetInfo(image_filter._get_handle() if image_filter else ffi.NULL, filter_info, size, data, size_ret)

def ImageFilterSetComputeType(image_filter, compute_type):
    return lib.rifImageFilterSetComputeType(image_filter._get_handle() if image_filter else ffi.NULL, compute_type)

def ImageFilterSetParameter16f(image_filter, name, val):
    return lib.rifImageFilterSetParameter16f(image_filter._get_handle() if image_filter else ffi.NULL, name, val)

def ImageFilterSetParameter1f(image_filter, name, x):
    return lib.rifImageFilterSetParameter1f(image_filter._get_handle() if image_filter else ffi.NULL, name, x)

def ImageFilterSetParameter1u(image_filter, name, x):
    return lib.rifImageFilterSetParameter1u(image_filter._get_handle() if image_filter else ffi.NULL, name, x)

def ImageFilterSetParameter2f(image_filter, name, x, y):
    return lib.rifImageFilterSetParameter2f(image_filter._get_handle() if image_filter else ffi.NULL, name, x, y)

def ImageFilterSetParameter2i(image_filter, name, x, y):
    return lib.rifImageFilterSetParameter2i(image_filter._get_handle() if image_filter else ffi.NULL, name, x, y)

def ImageFilterSetParameter2u(image_filter, name, x, y):
    return lib.rifImageFilterSetParameter2u(image_filter._get_handle() if image_filter else ffi.NULL, name, x, y)

def ImageFilterSetParameter3f(image_filter, name, x, y, z):
    return lib.rifImageFilterSetParameter3f(image_filter._get_handle() if image_filter else ffi.NULL, name, x, y, z)

def ImageFilterSetParameter4f(image_filter, name, x, y, z, w):
    return lib.rifImageFilterSetParameter4f(image_filter._get_handle() if image_filter else ffi.NULL, name, x, y, z, w)

def ImageFilterSetParameterFloatArray(image_filter, name, arr, num):
    return lib.rifImageFilterSetParameterFloatArray(image_filter._get_handle() if image_filter else ffi.NULL, name, arr, num)

def ImageFilterSetParameterImage(image_filter, name, img):
    return lib.rifImageFilterSetParameterImage(image_filter._get_handle() if image_filter else ffi.NULL, name, img._get_handle() if img else ffi.NULL)

def ImageFilterSetParameterImageArray(image_filter, name, arr, num):
    return lib.rifImageFilterSetParameterImageArray(image_filter._get_handle() if image_filter else ffi.NULL, name, arr._handle_ptr if arr else ffi.NULL, num)

def ImageFilterSetParameterString(image_filter, name, val):
    return lib.rifImageFilterSetParameterString(image_filter._get_handle() if image_filter else ffi.NULL, name, val)

def ImageGetInfo(image, image_info, size, data, size_ret):
    return lib.rifImageGetInfo(image._get_handle() if image else ffi.NULL, image_info, size, data, size_ret)

def ImageMap(image, map_type, data):
    return lib.rifImageMap(image._get_handle() if image else ffi.NULL, map_type, data)

def ImageUnmap(image, ptr):
    return lib.rifImageUnmap(image._get_handle() if image else ffi.NULL, ptr)

def ObjectDelete(obj):
    return lib.rifObjectDelete(obj)

def ParameterGetInfo(image_filter, paramIdx, param_info, size, data, size_ret):
    return lib.rifParameterGetInfo(image_filter._get_handle() if image_filter else ffi.NULL, paramIdx, param_info, size, data, size_ret)

def SetKernelsDir(context, kernels_dir):
    return lib.rifSetKernelsDir(context._get_handle() if context else ffi.NULL, kernels_dir)

def SyncronizeQueue(command_queue):
    return lib.rifSyncronizeQueue(command_queue._get_handle() if command_queue else ffi.NULL)

_functions_names = ['CommandQueueAttachImageFilter', 'CommandQueueAttachImageFilterRect', 'CommandQueueDetachImageFilter', 'ContextCreateCommandQueue', 'ContextCreateImage', 'ContextCreateImageFilter', 'ContextCreateImageFromOpenClMemory', 'ContextCreateImageFromOpenGlTexture', 'ContextExecuteCommandQueue', 'ContextGetDeviceInfo', 'ContextGetInfo', 'ContextSetInfo', 'CreateContext', 'CreateContextFromOpenClContext', 'CreateContextSharedWithOpenGl', 'FlushQueue', 'GetDeviceCount', 'GetErrorCodeDescription', 'GetErrorCodeString', 'GetKernelsDir', 'ImageFilterClearParameterImage', 'ImageFilterGetInfo', 'ImageFilterSetComputeType', 'ImageFilterSetParameter16f', 'ImageFilterSetParameter1f', 'ImageFilterSetParameter1u', 'ImageFilterSetParameter2f', 'ImageFilterSetParameter2i', 'ImageFilterSetParameter2u', 'ImageFilterSetParameter3f', 'ImageFilterSetParameter4f', 'ImageFilterSetParameterFloatArray', 'ImageFilterSetParameterImage', 'ImageFilterSetParameterImageArray', 'ImageFilterSetParameterString', 'ImageGetInfo', 'ImageMap', 'ImageUnmap', 'ObjectDelete', 'ParameterGetInfo', 'SetKernelsDir', 'SyncronizeQueue']
