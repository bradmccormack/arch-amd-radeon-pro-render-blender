version='2.0.112'
user='radeon'
timestamp=(2019, 7, 29, 17, 47, 0, 0, 210, -1)
target='linux'
    